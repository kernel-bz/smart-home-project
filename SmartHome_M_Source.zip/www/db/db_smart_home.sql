-- phpMyAdmin SQL Dump
-- version 4.6.6deb4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- 생성 시간: 18-01-12 19:40
-- 서버 버전: 10.1.23-MariaDB-9+deb9u1
-- PHP 버전: 7.0.19-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `db_smart_home`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `tbl_status`
--

CREATE TABLE `tbl_status` (
  `dno` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `dtime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='status of device running';

--
-- 테이블의 덤프 데이터 `tbl_status`
--

INSERT INTO `tbl_status` (`dno`, `status`, `dtime`) VALUES
(11, 0, '2018-01-12 20:07:32'),
(10, 0, '2018-01-12 20:07:32'),
(9, 0, '2018-01-12 20:07:32'),
(0, 0, '2018-01-12 20:07:32'),
(2, 0, '2018-01-12 20:07:32'),
(1, 0, '2018-01-12 20:07:32'),
(3, 0, '2018-01-12 20:07:32'),
(4, 0, '2018-01-12 20:07:32'),
(5, 0, '2018-01-12 20:07:32'),
(6, 0, '2018-01-12 20:07:32'),
(7, 0, '2018-01-12 20:07:32'),
(8, 0, '2018-01-12 20:07:32');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `tbl_status`
--
ALTER TABLE `tbl_status`
  ADD KEY `dno` (`dno`) USING BTREE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
