/**
 *  file name:  device_run.c
 *	comments:   SmartHomeM Control Main program
 *  author:     JungJaeJoon(rgbi3307@nate.com) on the www.kernel.bz
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>

#include "SmartHomeM.h"

int main (int argc, char **argv)
{
    int led_on[9] = { SM_CMD_LED_ALL_ON
          , SM_CMD_LED1_ON, SM_CMD_LED2_ON, SM_CMD_LED3_ON, SM_CMD_LED4_ON
          , SM_CMD_LED5_ON, SM_CMD_LED6_ON, SM_CMD_LED7_ON, SM_CMD_LED8_ON };

    int led_off[9] = { SM_CMD_LED_ALL_OFF
          , SM_CMD_LED1_OFF, SM_CMD_LED2_OFF, SM_CMD_LED3_OFF, SM_CMD_LED4_OFF
          , SM_CMD_LED5_OFF, SM_CMD_LED6_OFF, SM_CMD_LED7_OFF, SM_CMD_LED8_OFF };

	int idx, sw, ret=0;

	sm_start();

	if (argc > 2) {
        idx = atoi(argv[1]);
        sw = atoi(argv[2]);
        if (idx >= 0 && idx <= 8) {
            if (sw) ret = sm_command (led_on[idx]);
            else ret = sm_command (led_off[idx]);
        } else if (idx == 10) {
            ret = sm_motor (SM_CMD_MOTOR_CW, MOTOR_D90, MOTOR_S90);
        } else if (idx == 11) {
            ret = sm_motor (SM_CMD_MOTOR_CCW, MOTOR_D90, MOTOR_S90);
        }
	}

_end:
	sm_end();

	return ret;
}
